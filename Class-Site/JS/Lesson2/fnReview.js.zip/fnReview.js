// function addFunction() {
//   var a = 1;
//   var b = 3;
//   return a + b;
// }

// addFunction();
// console.log(addFunction());

// function addFunctionParam(num1, num2) {
//   var result = num1 + num2;
//   console.log(result);
//   return result;

//   // return num1 + num2;
// }

// var c = 22;
// var d = 123;
// addFunctionParam(c, d);

// var e = 123432;
// var r = 24523;
// addFunctionParam(e, r);

// var subFunction = function (num1, num2) {
//   var result = num2 - num1;
//   return result;
// };

// // console.log(subFunction(2, 4));

// function subFunction2(num1, num2) {
//   var sub = num2 - num1;
//   return sub;
// }

// var resultSub = subFunction2(3, 7);
// console.log(resultSub);

function tipCalculator(total, tip) {
  console.log("total", total);
  console.log("tip", tip);
  if (total && tip) {
    return total + tip;
  }

  // if (total === 40.0 || tip === 5.0) {
  //   console.log("hi");
  // }
}

var tipResult = tipCalculator(20.0, 10.0);
// var tipResult2 = tipCalculator(20.0, 20.0);
console.log(tipResult);
